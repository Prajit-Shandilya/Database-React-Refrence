import firebase from 'firebase';

var firebaseConfig = {
  apiKey: 'AIzaSyDN26eB3ucaHOnuQQv28TmPjmp3F5Dp9Q8',
  authDomain: 'buzzer-app-295b7.firebaseapp.com',
  databaseURL: 'https://buzzer-app-295b7-default-rtdb.firebaseio.com',
  projectId: 'buzzer-app-295b7',
  storageBucket: 'buzzer-app-295b7.appspot.com',
  messagingSenderId: '261685362308',
  appId: '1:261685362308:web:848def9995e88a5bc28cd1',
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

/*if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}*/
export default firebase.database();
